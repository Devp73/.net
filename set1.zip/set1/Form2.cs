﻿using System.Data;
using System.Data.SqlClient;

namespace set1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            cfill();
            cfill1();
            fill();
        }
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\DEV\Documents\exam.mdf;Integrated Security=True;Connect Timeout=30");
        void cfill()
        {
            cb_seasonName.Items.Clear();
            string q = "select type from seasons";
            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                cb_seasonName.Items.Add(sdr[0].ToString());
                cb_sname1.Items.Add(sdr[0].ToString());
            }
            con.Close();
        }

        int getId(string str)
        {
            int id;
            string q = "select id from seasons where type=@type";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@type", str);
            con.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            id = Convert.ToInt32(sdr[0]);
            con.Close();
            return id;
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            string q = "insert into customer values(@id,@name,@state,@mobile,@email,@sid)";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txt_id.Text));
            cmd.Parameters.AddWithValue("@name", txt_name.Text);
            cmd.Parameters.AddWithValue("@state", txt_state.Text);
            cmd.Parameters.AddWithValue("@mobile", txt_mobile.Text);
            cmd.Parameters.AddWithValue("@email", txt_email.Text);
            cmd.Parameters.AddWithValue("@sid", getId((string)cb_seasonName.Items[cb_seasonName.SelectedIndex]));
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            if (i > 0)
            {
                MessageBox.Show("Data inserted successfully");
            }
            cfill();

        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            string q = "select c.id,name,state,mobileno,emailid,type from customer c,seasons s where c.season_id=s.id";
            SqlDataAdapter sda = new SqlDataAdapter(q, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        void cfill1()
        {
            string q = "select id from customer";
            SqlCommand cmd = new SqlCommand(q, con);
            //con.Open();
            //SqlDataReader sdr = cmd.ExecuteReader();
            //while(sdr.Read())
            //{
            //    cb_cid.Items.Add(sdr[0].ToString());
            //}
            //con.Close();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            int r = dt.Rows.Count;
            for (int i = 0; i < r; i++)
            {
                cb_cid.Items.Add(dt.Rows[i][0].ToString());
            }
        }
        DataTable dt = new DataTable();
        int i=0,j=-1;
        private void cb_cid_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id1 = Convert.ToInt32(cb_cid.Items[cb_cid.SelectedIndex]);
            string q = "select c.id,name,state,mobileno,emailid,type from customer c,seasons s where c.season_id=s.id and c.id=@id";
            SqlCommand cmd = new SqlCommand(q, con);
            cmd.Parameters.AddWithValue("@id",id1);
            //con.Open();
            //SqlDataReader sdr = cmd.ExecuteReader();
            //sdr.Read();
            //txt_name1.Text = sdr[0].ToString();
            //txt_state1.Text = sdr[1].ToString();
            //txt_mobile1.Text = sdr[2].ToString();
            //txt_email1.Text = sdr[3].ToString();
            //txt_sname1.Text = sdr[4].ToString();
            //con.Close();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txt_id1.Text = dt.Rows[0][0].ToString();
            txt_name1.Text = dt.Rows[0][1].ToString();
            txt_state1.Text = dt.Rows[0][2].ToString();
            txt_mobile1.Text = dt.Rows[0][3].ToString();
            txt_email1.Text = dt.Rows[0][4].ToString();
            cb_sname1.Text = dt.Rows[0][5].ToString();
            j = cb_cid.SelectedIndex;
        }

        void fill()
        {
            string q = "select c.id,name,state,mobileno,emailid,type from customer c,seasons s where c.season_id=s.id";
            SqlDataAdapter sda = new SqlDataAdapter(q, con);
            sda.Fill(dt);
            i = dt.Rows.Count;
        }

        private void btn_prev_Click(object sender, EventArgs e)
        {
            if(j == 0 || j==-1)
            {
                j = i - 1;
            }
            else
            {
                j--;
            }
            txt_id1.Text = dt.Rows[j][0].ToString();
            txt_name1.Text = dt.Rows[j][1].ToString();
            txt_state1.Text = dt.Rows[j][2].ToString();
            txt_mobile1.Text = dt.Rows[j][3].ToString();
            txt_email1.Text = dt.Rows[j][4].ToString();
            cb_sname1.Text = dt.Rows[j][5].ToString();
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            var x = MessageBox.Show("Are you sure you want to update?", "Update", MessageBoxButtons.YesNo);
            if(x == DialogResult.Yes)
            {
                string q = "update customer set name=@name,state=@state,mobileno=@no,emailid=@email,season_id=@sid where id=@id";
                SqlCommand cmd = new SqlCommand(q, con);
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txt_id1.Text));
                cmd.Parameters.AddWithValue("@name", txt_name1.Text);
                cmd.Parameters.AddWithValue("@state", txt_state1.Text);
                cmd.Parameters.AddWithValue("@no", txt_mobile1.Text);
                cmd.Parameters.AddWithValue("@email", txt_email1.Text);
                cmd.Parameters.AddWithValue("@sid", getId((string)cb_sname1.Items[cb_sname1.SelectedIndex]));
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
                if (i > 0)
                {
                    MessageBox.Show("Data Updated successfully");
                    fill();
                }

            }
        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            j++;
            if (j == i)
                j = 0;
            txt_id1.Text = dt.Rows[j][0].ToString();
            txt_name1.Text = dt.Rows[j][1].ToString();
            txt_state1.Text = dt.Rows[j][2].ToString();
            txt_mobile1.Text = dt.Rows[j][3].ToString();
            txt_email1.Text = dt.Rows[j][4].ToString();
            cb_sname1.Text = dt.Rows[j][5].ToString();

        }
    }
}
