using System.Text.RegularExpressions;

namespace set1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int y = Convert.ToInt32(textBox1.Text);
            if(y%4 == 0)
            {
                MessageBox.Show("Given year is leap year");
            }
            else
            {
                MessageBox.Show("Given year is not leap year");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Regex regex = new Regex("^[0-9]+$");
            if (!(regex.IsMatch(textBox1.Text)))
            {
                MessageBox.Show("Please enter numbers only");
                textBox1.Text = "";
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
            if(e.Handled)
            {
                MessageBox.Show("Please enter only digits");
            }
        }
    }
}